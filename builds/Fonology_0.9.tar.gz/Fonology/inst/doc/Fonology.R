## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(dplyr)
library(stringr)
library(tibble)

## ----message=F----------------------------------------------------------------
library(Fonology)

getFeat(ph = c("i", "u"), lg = "English")
getFeat(ph = c("i", "u"), lg = "French")
getFeat(ph = c("i", "y", "u"), lg = "French")
getFeat(ph = c("p", "b"), lg = "Portuguese")


## ----message=F----------------------------------------------------------------
getPhon(ft = c("+syl", "+hi"), lg = "French")
getPhon(ft = c("-DR", "-cont", "-son"), lg = "English")
getPhon(ft = c("-son", "+vce"), lg = "Spanish")


## ----message=F----------------------------------------------------------------
ipa("atletico")
ipa("cantalo", narrow = T)
ipa("antidepressivo", narrow = T)
ipa("feris") 
ipa("mejorado", lg = "sp")
ipa("nuevos", lg = "sp")

## ----message=F----------------------------------------------------------------
example = tibble(word = c("partolo", "metrilpo", "vanplidos"))

example = example |> 
  rowwise() |> 
  mutate(ipa = ipa_pt(word),
         syl2 = getSyl(word = ipa, pos = 2),
         demi1 = demi(word = syl2, d = 1),
         disp = sonDisp(demi = demi1),
         SSP = ssp(demi = demi1, d = 1))

example

## ----message=F----------------------------------------------------------------
meanSonDisp(word = c("partolo", "metrilpo", "vanplidos"))

## ----message=FALSE------------------------------------------------------------
set.seed(1)
wug_pt(profile = "LHL")

# Let's create a table with 5 nonce words and their bigram probability
set.seed(1)
tibble(word = wug_pt("LHL", n = 5)) |>
  mutate(bigram = word |> biGram_pt())

